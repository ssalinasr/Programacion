
package biginteger;
import java.math.BigInteger;
public class BigInteger {


    
    //manejo similar
    //Dado un valor en tarjeta credito
    //Verificar si es valido o no
    //Utilizando BigInteger y sus operaciones
    
    

    public static void main(String[] args) {
    BigInteger a;
    
    }
    
}
