 # Contador para realizacion de una rutina

__Integrantes__:

 - Julian Andres Sanchez Rivera 20181020169
 - Sebastian Salinas 		20181020058

Ejercicio de contador para la realizacion durante un periodo de tiempo de ciertos ejercicios,
con el objetivo de entender el modelo BigBang dentro de la creacion de SoftWare.

Realizado utilizando swing, Timer y sound para el manejo de sonidos

__Recordatorio__:
Debe cambiarse la direccion de los sonidos

