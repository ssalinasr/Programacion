
package codigoLexicoBasico;

public enum Tokens {
    Reservadas,
    Igual,
    Suma,
    Resta,
    Multiplicacion,
    Division,
    P_coma,
    Identificador,
    Numero,
    ERROR
}
