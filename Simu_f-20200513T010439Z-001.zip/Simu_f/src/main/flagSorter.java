/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import javax.swing.ImageIcon;

/**
 *
 * @author sebas
 */
public class flagSorter {
    
    public ImageIcon setFlags(String country){
        ImageIcon f;
        switch(country){
            case "Afganistan":
                f = new ImageIcon(getClass().getResource("/banderas/afganistan.jpg"));
                break;
            case "Albania":
                f = new ImageIcon(getClass().getResource("/banderas/albania.jpg"));
                break;
            case "Alemania":
                f = new ImageIcon(getClass().getResource("/banderas/alemania.jpg"));
                break;
                
            case "Andorra":
                f = new ImageIcon(getClass().getResource("/banderas/andorra.jpg"));
                break;
            case "Angola":
                f = new ImageIcon(getClass().getResource("/banderas/angola.jpg"));
                break;
            case "Arabia Saudita":
                f = new ImageIcon(getClass().getResource("/banderas/arabia saudita.jpg"));
                break;
                
            case "Argelia":
                f = new ImageIcon(getClass().getResource("/banderas/argelia.jpg"));
                break;
            case "Argentina":
                f = new ImageIcon(getClass().getResource("/banderas/argentina.jpg"));
                break;
            case "Armenia":
                f = new ImageIcon(getClass().getResource("/banderas/armenia.jpg"));
                break;
                
            case "Australia":
                f = new ImageIcon(getClass().getResource("/banderas/australia.jpg"));
                break;
            case "Austria":
                f = new ImageIcon(getClass().getResource("/banderas/austria.jpg"));
                break;
            case "Azerbaijan":
                f = new ImageIcon(getClass().getResource("/banderas/azerbaijan.jpg"));
                break;
                
            case "Bahamas":
                f = new ImageIcon(getClass().getResource("/banderas/bahamas.jpg"));
                break;
            case "Bahrein":
                f = new ImageIcon(getClass().getResource("/banderas/bahrein.jpg"));
                break;
            case "Barbados":
                f = new ImageIcon(getClass().getResource("/banderas/barbados.jpg"));
                break;
                
            case "Belarus":
                f = new ImageIcon(getClass().getResource("/banderas/belarus.jpg"));
                break;
            case "Belgica":
                f = new ImageIcon(getClass().getResource("/banderas/belgica.jpg"));
                break;
            case "Bolivia":
                f = new ImageIcon(getClass().getResource("/banderas/bolivia.jpg"));
                break;
                
            case "Bosnia":
                f = new ImageIcon(getClass().getResource("/banderas/bosnia.jpg"));
                break;
                
            case "Brasil":
                f = new ImageIcon(getClass().getResource("/banderas/brasil.jpg"));
                break;
            case "Bulgaria":
                f = new ImageIcon(getClass().getResource("/banderas/bulgaria.jpg"));
                break;
            case "Burkina Faso":
                f = new ImageIcon(getClass().getResource("/banderas/burkina faso.jpg"));
                break;
                
            case "Camerun":
                f = new ImageIcon(getClass().getResource("/banderas/camerun.jpg"));
                break;
            case "Canada":
                f = new ImageIcon(getClass().getResource("/banderas/canada.jpg"));
                break;
            case "Chile":
                f = new ImageIcon(getClass().getResource("/banderas/chile.jpg"));
                break;
                
            case "China":
                f = new ImageIcon(getClass().getResource("/banderas/china.jpg"));
                break;
            case "Chipre":
                f = new ImageIcon(getClass().getResource("/banderas/chipre.jpg"));
                break;
            case "Colombia":
                f = new ImageIcon(getClass().getResource("/banderas/colombia.jpg"));
                break;
               
            case "Congo":
                f = new ImageIcon(getClass().getResource("/banderas/congo.jpg"));
                break;
            case "Corea del Norte":
                f = new ImageIcon(getClass().getResource("/banderas/corea del norte.jpg"));
                break;
            case "Corea del Sur":
                f = new ImageIcon(getClass().getResource("/banderas/corea del sur.jpg"));
                break;
                
            case "Costa de Marfil":
                f = new ImageIcon(getClass().getResource("/banderas/costa de marfil.jpg"));
                break;
            case "Costa Rica":
                f = new ImageIcon(getClass().getResource("/banderas/costa rica.jpg"));
                break;
            case "Croacia":
                f = new ImageIcon(getClass().getResource("/banderas/croacia.jpg"));
                break;
                
            case "Cuba":
                f = new ImageIcon(getClass().getResource("/banderas/cuba.jpg"));
                break;
            case "Dinamarca":
                f = new ImageIcon(getClass().getResource("/banderas/dinamarca.jpg"));
                break;
            case "Ecuador":
                f = new ImageIcon(getClass().getResource("/banderas/ecuador.jpg"));
                break;
                
            case "Egipto":
                f = new ImageIcon(getClass().getResource("/banderas/egipto.jpg"));
                break;
            case "El Salvador":
                f = new ImageIcon(getClass().getResource("/banderas/el salvador.jpg"));
                break;
            case "Emiratos Arabes Unidos":
                f = new ImageIcon(getClass().getResource("/banderas/emiratos arabes unidos.jpg"));
                break;
                
            case "Escocia":
                f = new ImageIcon(getClass().getResource("/banderas/escocia.png"));
                break;
            case "Eslovaquia":
                f = new ImageIcon(getClass().getResource("/banderas/eslovaquia.jpg"));
                break;
            case "Eslovenia":
                f = new ImageIcon(getClass().getResource("/banderas/eslovenia.jpg"));
                break;
                
            case "España":
                f = new ImageIcon(getClass().getResource("/banderas/españa.jpg"));
                break;
            case "Estados Unidos":
                f = new ImageIcon(getClass().getResource("/banderas/estados unidos.jpg"));
                break;
            case "Estonia":
                f = new ImageIcon(getClass().getResource("/banderas/estonia.jpg"));
                break;
                
            case "Etiopia":
                f = new ImageIcon(getClass().getResource("/banderas/etiopia.jpg"));
                break;
            case "Fiji":
                f = new ImageIcon(getClass().getResource("/banderas/fiji.jpg"));
                break;
            case "Filipinas":
                f = new ImageIcon(getClass().getResource("/banderas/filipinas.jpg"));
                break;
                
            case "Finlandia":
                f = new ImageIcon(getClass().getResource("/banderas/finlandia.jpg"));
                break;
            case "Francia":
                f = new ImageIcon(getClass().getResource("/banderas/francia.jpg"));
                break;
            case "Gales":
                f = new ImageIcon(getClass().getResource("/banderas/gales.png"));
                break;
                
            case "Georgia":
                f = new ImageIcon(getClass().getResource("/banderas/georgia.jpg"));
                break;
            case "Ghana":
                f = new ImageIcon(getClass().getResource("/banderas/ghana.jpg"));
                break;
            case "Grecia":
                f = new ImageIcon(getClass().getResource("/banderas/grecia.jpg"));
                break;
                
            case "Guinea":
                f = new ImageIcon(getClass().getResource("/banderas/guinea.jpg"));
                break;
            case "Haiti":
                f = new ImageIcon(getClass().getResource("/banderas/haiti.jpg"));
                break;
            case "Holanda":
                f = new ImageIcon(getClass().getResource("/banderas/holanda.jpg"));
                break;
                
            case "Honduras":
                f = new ImageIcon(getClass().getResource("/banderas/honduras.jpg"));
                break;
            case "Hungria":
                f = new ImageIcon(getClass().getResource("/banderas/hungria.jpg"));
                break;
            case "India":
                f = new ImageIcon(getClass().getResource("/banderas/india.jpg"));
                break;
                
            case "Indonesia":
                f = new ImageIcon(getClass().getResource("/banderas/indonesia.jpg"));
                break;
            case "Inglaterra":
                f = new ImageIcon(getClass().getResource("/banderas/inglaterra.png"));
                break;
            case "Irak":
                f = new ImageIcon(getClass().getResource("/banderas/irak.jpg"));
                break;
                
            case "Iran":
                f = new ImageIcon(getClass().getResource("/banderas/iran.jpg"));
                break;
            case "Irlanda del Norte":
                f = new ImageIcon(getClass().getResource("/banderas/irlanda del norte.png"));
                break;
            case "Irlanda":
                f = new ImageIcon(getClass().getResource("/banderas/irlanda.jpg"));
                break;
                
            case "Islandia":
                f = new ImageIcon(getClass().getResource("/banderas/islandia.jpg"));
                break;
            case "Israel":
                f = new ImageIcon(getClass().getResource("/banderas/israel.jpg"));
                break;
            case "Italia":
                f = new ImageIcon(getClass().getResource("/banderas/italia.jpg"));
                break;
                
            case "Jamaica":
                f = new ImageIcon(getClass().getResource("/banderas/jamaica.jpg"));
                break;
            case "Japón":
                f = new ImageIcon(getClass().getResource("/banderas/japon.jpg"));
                break;
            case "Jordania":
                f = new ImageIcon(getClass().getResource("/banderas/jordania.jpg"));
                break;
                
            case "Kazajistan":
                f = new ImageIcon(getClass().getResource("/banderas/kazajistan.jpg"));
                break;
            case "Kenia":
                f = new ImageIcon(getClass().getResource("/banderas/kenia.jpg"));
                break;
            case "Kirguistan":
                f = new ImageIcon(getClass().getResource("/banderas/kirguistan.jpg"));
                break;
                
            case "Kuwait":
                f = new ImageIcon(getClass().getResource("/banderas/kuwait.jpg"));
                break;
            case "Letonia":
                f = new ImageIcon(getClass().getResource("/banderas/letonia.jpg"));
                break;
            case "Libano":
                f = new ImageIcon(getClass().getResource("/banderas/libano.jpg"));
                break;
                
            case "Liberia":
                f = new ImageIcon(getClass().getResource("/banderas/liberia.jpg"));
                break;
            case "Liechtenstein":
                f = new ImageIcon(getClass().getResource("/banderas/liechtenstein.jpg"));
                break;
            case "Lituania":
                f = new ImageIcon(getClass().getResource("/banderas/lituania.jpg"));
                break;
                
            case "Luxemburgo":
                f = new ImageIcon(getClass().getResource("/banderas/luxemburgo.jpg"));
                break;
            case "Macedonia":
                f = new ImageIcon(getClass().getResource("/banderas/macedonia.jpg"));
                break;
            case "Malasia":
                f = new ImageIcon(getClass().getResource("/banderas/malasia.jpg"));
                break;
                
            case "Mali":
                f = new ImageIcon(getClass().getResource("/banderas/mali.jpg"));
                break;
            case "Malta":
                f = new ImageIcon(getClass().getResource("/banderas/malta.jpg"));
                break;
            case "Marruecos":
                f = new ImageIcon(getClass().getResource("/banderas/marruecos.jpg"));
                break;
                
            case "Mexico":
                f = new ImageIcon(getClass().getResource("/banderas/mexico.jpg"));
                break;
            case "Moldavia":
                f = new ImageIcon(getClass().getResource("/banderas/moldavia.jpg"));
                break;
            case "Monaco":
                f = new ImageIcon(getClass().getResource("/banderas/monaco.jpg"));
                break;
                
            case "Mongolia":
                f = new ImageIcon(getClass().getResource("/banderas/mongolia.jpg"));
                break;
            case "Montenegro":
                f = new ImageIcon(getClass().getResource("/banderas/montenegro.jpg"));
                break;
            case "Nepal":
                f = new ImageIcon(getClass().getResource("/banderas/nepal.jpg"));
                break;
                
            case "Nicaragua":
                f = new ImageIcon(getClass().getResource("/banderas/nicaragua.jpg"));
                break;
            case "Nigeria":
                f = new ImageIcon(getClass().getResource("/banderas/nigeria.jpg"));
                break;
            case "Noruega":
                f = new ImageIcon(getClass().getResource("/banderas/noruega.jpg"));
                break;
                
                
            case "Nueva Zelanda":
                f = new ImageIcon(getClass().getResource("/banderas/nueva zelanda.jpg"));
                break;
            case "Oman":
                f = new ImageIcon(getClass().getResource("/banderas/oman.jpg"));
                break;
            case "Pakistan":
                f = new ImageIcon(getClass().getResource("/banderas/pakistan.jpg"));
                break;
                
                
            case "Panama":
                f = new ImageIcon(getClass().getResource("/banderas/panama.jpg"));
                break;
            case "Papua Nueva Guinea":
                f = new ImageIcon(getClass().getResource("/banderas/papua nueva guinea.jpg"));
                break;
            case "Paraguay":
                f = new ImageIcon(getClass().getResource("/banderas/paraguay.jpg"));
                break;
                
                
            case "Peru":
                f = new ImageIcon(getClass().getResource("/banderas/peru.jpg"));
                break;
            case "Polonia":
                f = new ImageIcon(getClass().getResource("/banderas/polonia.jpg"));
                break;
            case "Portugal":
                f = new ImageIcon(getClass().getResource("/banderas/portugal.jpg"));
                break;
                
                
            case "Qatar":
                f = new ImageIcon(getClass().getResource("/banderas/qatar.jpg"));
                break;
            case "Republica Centroafricana":
                f = new ImageIcon(getClass().getResource("/banderas/republica centroafricana.jpg"));
                break;
            case "Republica Checa":
                f = new ImageIcon(getClass().getResource("/banderas/republica checa.jpg"));
                break;
                
                
            case "Republica Democratica del Congo":
                f = new ImageIcon(getClass().getResource("/banderas/republica democratica del congo.jpg"));
                break;
            case "Rumania":
                f = new ImageIcon(getClass().getResource("/banderas/rumania.jpg"));
                break;
            case "Rusia":
                f = new ImageIcon(getClass().getResource("/banderas/rusia.jpg"));
                break;
                
                
            case "San Marino":
                f = new ImageIcon(getClass().getResource("/banderas/san marino.jpg"));
                break;
            case "Senegal":
                f = new ImageIcon(getClass().getResource("/banderas/senegal.jpg"));
                break;
            case "Serbia":
                f = new ImageIcon(getClass().getResource("/banderas/serbia.jpg"));
                break;
                
                
            case "Singapur":
                f = new ImageIcon(getClass().getResource("/banderas/singapur.jpg"));
                break;
            case "Sudafrica":
                f = new ImageIcon(getClass().getResource("/banderas/sudafrica.jpg"));
                break;
            case "Sudan":
                f = new ImageIcon(getClass().getResource("/banderas/sudan.jpg"));
                break;
                
                
            case "Suecia":
                f = new ImageIcon(getClass().getResource("/banderas/suecia.png"));
                break;
            case "Suiza":
                f = new ImageIcon(getClass().getResource("/banderas/suiza.jpg"));
                break;
            case "Tailandia":
                f = new ImageIcon(getClass().getResource("/banderas/tailandia.jpg"));
                break;
                
                
            case "Tanzania":
                f = new ImageIcon(getClass().getResource("/banderas/tanzania.jpg"));
                break;
            case "Tayikistan":
                f = new ImageIcon(getClass().getResource("/banderas/tayikistan.jpg"));
                break;
            case "Trinidad y Tobago":
                f = new ImageIcon(getClass().getResource("/banderas/trinidad y tobago.jpg"));
                break;
                
                
            case "Tunez":
                f = new ImageIcon(getClass().getResource("/banderas/tunez.jpg"));
                break;
            case "Turkmenistan":
                f = new ImageIcon(getClass().getResource("/banderas/turkmenistan.jpg"));
                break;
            case "Turquia":
                f = new ImageIcon(getClass().getResource("/banderas/turquia.jpg"));
                break;
                
                
            case "Ucrania":
                f = new ImageIcon(getClass().getResource("/banderas/ucrania.jpg"));
                break;
            case "Uruguay":
                f = new ImageIcon(getClass().getResource("/banderas/uruguay.jpg"));
                break;
            case "Uzbekistan":
                f = new ImageIcon(getClass().getResource("/banderas/uzbekistan.jpg"));
                break;
                
                
            case "Venezuela":
                f = new ImageIcon(getClass().getResource("/banderas/venezuela.jpg"));
                break;
            case "Vietnam":
                f = new ImageIcon(getClass().getResource("/banderas/vietnam.jpg"));
                break;
            case "Zambia":
                f = new ImageIcon(getClass().getResource("/banderas/zambia.jpg"));
                break;
                
                
            case "Zimbaue":
                f = new ImageIcon(getClass().getResource("/banderas/zimbaue.jpg"));
                break;
                
                                
            case "Islas Feroe":
                f = new ImageIcon(getClass().getResource("/banderas/islas feroe.png"));
                break;
                
                                
            case "Kosovo":
                f = new ImageIcon(getClass().getResource("/banderas/kosovo.png"));
                break;
                
                                
            case "Hong Kong":
                f = new ImageIcon(getClass().getResource("/banderas/hong kong.png"));
                break;
                
                                
            case "Taiwan":
                f = new ImageIcon(getClass().getResource("/banderas/taiwan.png"));
                break;
                
                                
            case "Birmania":
                f = new ImageIcon(getClass().getResource("/banderas/birmania.png"));
                break;
                
                                
            case "World Stars":
                f = new ImageIcon(getClass().getResource("/banderas/blank.jpg"));
                break;
                
                                
            case "Asia Stars":
                f = new ImageIcon(getClass().getResource("/banderas/blank.jpg"));
                break;
                
                                
            case "America Stars":
                f = new ImageIcon(getClass().getResource("/banderas/blank.jpg"));
                break;
                
                                
            case "Europe Stars":
                f = new ImageIcon(getClass().getResource("/banderas/blank.jpg"));
                break;
                
                                
            case "Africa Stars":
                f = new ImageIcon(getClass().getResource("/banderas/blank.jpg"));
                break;
            default:
                f = new ImageIcon();
                break;
                
        }
        return f;       
    }
    
}
