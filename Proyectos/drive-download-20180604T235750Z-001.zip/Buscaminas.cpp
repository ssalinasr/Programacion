#include <iostream>
#include <stdlib.h>
using namespace std;

int valor_aleatorio(int n){//valor aleatorio minas
	int rand1=rand()%n;
	return rand1;
}

int main(){
	int n,minas1,minas2,contadorminas,contadorespacios;
	bool condvic=false;
	cin>>n;
	if (n>=10 && n<=20){
			int matriz_principal[n][n];//generar buscaminas
	int matriz_comparativa[n][n];//comparativo seg�n jugada
	for (int i=0;i<n;i++){//generaci�n minas
		for (int j=0;j<n;j++){
			minas1=valor_aleatorio(n);
			minas2=valor_aleatorio(n);
			if (i==minas1 || i==minas2 || j==minas1 || j==minas2){
				matriz_principal[i][j]=0;
				contadorminas++;
			}
			else{
				matriz_principal[i][j]=1;
				contadorespacios++;

			}
			
		}
		cout<<endl;
	}
		for (int i=0;i<n;i++){//generacion comparativa
		for (int j=0;j<n;j++){
		matriz_comparativa[i][j]=1;		
		}
		cout<<endl;
	}
	
 		system("cls");
	for (int i=0;i<n;i++){//llenado del tablero
		for (int j=0;j<n;j++){
			if(matriz_principal[i][j]==1 || matriz_principal[i][j]==0){
				cout<<" "<<" ";
			}
			if(matriz_principal[i][j]==2){
				cout<<"X"<<" ";
			}
			if(matriz_principal[i][j]==3 || matriz_principal[i][j]==4){
			cout<<"b"<<" ";
			}
		}
		cout<<endl;
	}
	
	while(condvic==false){
		if (contadorespacios==0){
			condvic=true;
			cout<<"felicitaciones, has ganado! =)"<<endl;
		}
		int mov;
		cout<<"acciones: 0=descubrir 1=marcar 2=desmarcar"<<endl;
		cin>>mov;
		if(mov==0){
			cout<<"en que coordenadas"<<endl;
			int xc,yc;
			cin>>xc;
			cin>>yc;
			if (matriz_principal[xc][yc]==3){
				matriz_principal[xc][yc]=1;
			}
			if (matriz_principal[xc][yc]==4){
				matriz_principal[xc][yc]=0;
			}
			if (matriz_principal[xc][yc]==1){
			matriz_principal[xc][yc]=2;
			system("cls");
			contadorespacios--;
	        for (int i=0;i<n;i++){//llenado del tablero
		    for (int j=0;j<n;j++){
			if(matriz_principal[i][j]==1 || matriz_principal[i][j]==0){
				cout<<" "<<" ";
			}
			if(matriz_principal[i][j]==2){
				cout<<"1"<<" ";
			}
				if(matriz_principal[i][j]==3 || matriz_principal[i][j]==4){
				cout<<"b"<<" ";
			}
		}
		cout<<endl;
	}
			}
			else{
			if (matriz_principal[xc][yc]==0){
					system("cls");
			for (int i=0;i<n;i++){
				for (int j=0;j<n;j++){
					if (matriz_principal[i][j]==0){
						cout<<"*"<<" ";
					}
					if (matriz_principal[i][j]==1 || matriz_principal[i][j]==2){
						cout<<"1"<<" ";
					}
				if(matriz_principal[i][j]==3 || matriz_principal[i][j]==4){
				cout<<"b"<<" ";
			}
					
				}
				cout<<endl;
			}
			condvic=true;
			cout<<endl;
			cout<<"juego terminado! =("<<endl;
			}

			}	
			}
			if (mov==1){
			cout<<"en que coordenadas"<<endl;
			int xc,yc;
			cin>>xc;
			cin>>yc;
			if (matriz_principal[xc][yc]==1){
			matriz_principal[xc][yc]=3;
			system("cls");
			}
			else{
			if (matriz_principal[xc][yc]==0){
			matriz_principal[xc][yc]=4;
			system("cls");
			}
			else{
			system("cls");
			cout<<"esa casilla ya esta marcada o bien, ya esta descubierta xd"<<endl;
			}
			}
			for (int i=0;i<n;i++){//llenado del tablero
		    for (int j=0;j<n;j++){
			if(matriz_principal[i][j]==1 || matriz_principal[i][j]==0){
				cout<<" "<<" ";
			}
			if(matriz_principal[i][j]==2){
				cout<<"1"<<" ";
			}
			if(matriz_principal[i][j]==3 || matriz_principal[i][j]==4){
				cout<<"b"<<" ";
			}
		}
		cout<<endl;
	}		
	}
	if (mov==2){
			cout<<"en que coordenadas"<<endl;
			int xc,yc;
			cin>>xc;
			cin>>yc;
			if (matriz_principal[xc][yc]==3){
			matriz_principal[xc][yc]=1;
			system("cls");
			}
			else{
			if (matriz_principal[xc][yc]==4){
			matriz_principal[xc][yc]=0;
			system("cls");
			}
			else{
			system("cls");
			cout<<"esa casilla no esta marcada xd"<<endl;
		
	}
	}
			for (int i=0;i<n;i++){//llenado del tablero
		    for (int j=0;j<n;j++){
			if(matriz_principal[i][j]==1 || matriz_principal[i][j]==0){
				cout<<" "<<" ";
			}
			if(matriz_principal[i][j]==2){
				cout<<"1"<<" ";
			}
			if(matriz_principal[i][j]==3 || matriz_principal[i][j]==4){
				cout<<"b"<<" ";
			}
		}
		cout<<endl;
	}

}
if(mov>2){
	system("cls");
				for (int i=0;i<n;i++){//llenado del tablero
		    for (int j=0;j<n;j++){
			if(matriz_principal[i][j]==1 || matriz_principal[i][j]==0){
				cout<<" "<<" ";
			}
			if(matriz_principal[i][j]==2){
				cout<<"1"<<" ";
			}
			if(matriz_principal[i][j]==3 || matriz_principal[i][j]==4){
				cout<<"b"<<" ";
			}
		}
		cout<<endl;
	}
	cout<<"ese valor no corresponde a ninguna funcion"<<endl;
}
	
}
}
else{
	cout<<"valor no valido"<<endl;
}
}





	
