
package cadenas;

public class InicioV {
    
    public static void main(String[] args) {
    Cadenas y;
    y=new Cadenas();
    y.funcion();
    
    }
    
    
}
