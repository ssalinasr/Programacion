
package ascensor;

public class edificioA {
        public static void main(String[] args) {
        Secuencia obj;
        obj=new Secuencia();
        obj.funciona();     
    }
    
}
