

package proyecto;

import javax.swing.JOptionPane;


public class SimLanzamientos extends javax.swing.JFrame {


    public SimLanzamientos() {
        initComponents();

        setLocationRelativeTo(null);
        setTitle("Ejercicio 5");
        BtnGroupRta1.add(Respuesta1A);
        BtnGroupRta1.add(Respuesta1B);
        BtnGroupRta1.add(Respuesta1C);
        BtnGroupRta1.add(Respuesta1D);
        BtnGroupRta2.add(Respuesta2A);
        BtnGroupRta2.add(Respuesta2B);
        BtnGroupRta2.add(Respuesta2C);
        BtnGroupRta2.add(Respuesta2D);       
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BtnGroupRta1 = new javax.swing.ButtonGroup();
        BtnGroupRta2 = new javax.swing.ButtonGroup();
        BtnContinuar = new javax.swing.JButton();
        TxtSimular = new javax.swing.JLabel();
        BtnSimular = new javax.swing.JButton();
        TxtExplicacion = new javax.swing.JLabel();
        ImagenDado = new javax.swing.JLabel();
        Respuesta1B = new javax.swing.JRadioButton();
        Respuesta1D = new javax.swing.JRadioButton();
        Respuesta1C = new javax.swing.JRadioButton();
        Respuesta1A = new javax.swing.JRadioButton();
        TxtPregunta1 = new javax.swing.JLabel();
        TxtPregunta2 = new javax.swing.JLabel();
        Respuesta2A = new javax.swing.JRadioButton();
        Respuesta2B = new javax.swing.JRadioButton();
        Respuesta2C = new javax.swing.JRadioButton();
        Respuesta2D = new javax.swing.JRadioButton();
        TxtTitulo = new javax.swing.JLabel();
        TxtExplicacion2 = new javax.swing.JLabel();
        TxtExplicacion3 = new javax.swing.JLabel();
        TxtResultado = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        MenuOpciones = new javax.swing.JMenu();
        ItemSalir = new javax.swing.JMenuItem();
        MenuAcercade = new javax.swing.JMenu();
        ItemAbout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(475, 410));

        BtnContinuar.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnContinuar.setText("Next");
        BtnContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnContinuarActionPerformed(evt);
            }
        });

        TxtSimular.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        TxtSimular.setText("Simluate dice");

        BtnSimular.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnSimular.setText("Simulate");
        BtnSimular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnSimularActionPerformed(evt);
            }
        });

        TxtExplicacion.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        TxtExplicacion.setText("-Supose two dices (Values between 1-6 each one)");
        TxtExplicacion.setVerifyInputWhenFocusTarget(false);
        TxtExplicacion.setVerticalTextPosition(javax.swing.SwingConstants.TOP);

        ImagenDado.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        ImagenDado.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ImagenDado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Dadoicon.png"))); // NOI18N
        ImagenDado.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        Respuesta1B.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta1B.setText("10-12");

        Respuesta1D.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta1D.setText("4-7");

        Respuesta1C.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta1C.setText("1-6");

        Respuesta1A.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta1A.setText("5-8");

        TxtPregunta1.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        TxtPregunta1.setText("Most repeated result?");

        TxtPregunta2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        TxtPregunta2.setText("Less repeated result?");

        Respuesta2A.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta2A.setText("2-12");

        Respuesta2B.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta2B.setText("1-6");

        Respuesta2C.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta2C.setText("5-7");

        Respuesta2D.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta2D.setText("11-6");

        TxtTitulo.setFont(new java.awt.Font("Sitka Small", 3, 12)); // NOI18N
        TxtTitulo.setText("Throwing Simulator Exercise");

        TxtExplicacion2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        TxtExplicacion2.setText("-Supose that they are throwed n-times(with variable results between 2-12)");

        TxtExplicacion3.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        TxtExplicacion3.setText("-What happens if they are throwed 1000 times?");

        TxtResultado.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N

        MenuOpciones.setText("Options");

        ItemSalir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_MASK));
        ItemSalir.setText("Exit");
        ItemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemSalirActionPerformed(evt);
            }
        });
        MenuOpciones.add(ItemSalir);

        jMenuBar1.add(MenuOpciones);

        MenuAcercade.setText("About of");
        MenuAcercade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuAcercadeActionPerformed(evt);
            }
        });

        ItemAbout.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        ItemAbout.setText("About of");
        ItemAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemAboutActionPerformed(evt);
            }
        });
        MenuAcercade.add(ItemAbout);

        jMenuBar1.add(MenuAcercade);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TxtExplicacion3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(TxtTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(TxtExplicacion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(TxtExplicacion2, javax.swing.GroupLayout.DEFAULT_SIZE, 455, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TxtPregunta1)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(Respuesta1B, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 76, Short.MAX_VALUE)
                                        .addComponent(Respuesta1A, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(Respuesta1D, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TxtPregunta2, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(Respuesta2B, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Respuesta2A, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Respuesta2C, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Respuesta2D, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(31, 31, 31)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TxtSimular, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(BtnSimular, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(ImagenDado, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TxtResultado, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(8, 8, 8))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Respuesta1C, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(154, 154, 154)
                        .addComponent(BtnContinuar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TxtTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TxtExplicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TxtExplicacion2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TxtExplicacion3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TxtPregunta1)
                            .addComponent(TxtPregunta2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Respuesta1A)
                            .addComponent(Respuesta2A))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Respuesta1B)
                            .addComponent(Respuesta2B, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Respuesta2C)
                            .addComponent(Respuesta1C))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Respuesta1D)
                            .addComponent(Respuesta2D))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(BtnContinuar)
                        .addGap(29, 29, 29))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(TxtSimular, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ImagenDado, javax.swing.GroupLayout.DEFAULT_SIZE, 94, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(BtnSimular)
                        .addGap(18, 18, 18)
                        .addComponent(TxtResultado, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(47, 47, 47))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ItemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemSalirActionPerformed
         System.exit(0);
    }//GEN-LAST:event_ItemSalirActionPerformed

    private void MenuAcercadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuAcercadeActionPerformed

    }//GEN-LAST:event_MenuAcercadeActionPerformed

    private void ItemAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemAboutActionPerformed
         JOptionPane.showMessageDialog(this,"Project created for Final Note of POO 2018-3","About of",1);
    }//GEN-LAST:event_ItemAboutActionPerformed

    private void BtnContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnContinuarActionPerformed
        if(Respuesta1D.isSelected() && Respuesta2A.isSelected()){
            JOptionPane.showMessageDialog(this,"Correct Answer: 4-7 are the most repeated results and 2-12 are the less repeated","Congratulations",1);
            EjerMatematico e = new EjerMatematico();
            e.setVisible(true);
            dispose();
        }
        else{
            JOptionPane.showMessageDialog(this,"Incorrect Answer: Try again","Bad Luck",2);
        }
    }//GEN-LAST:event_BtnContinuarActionPerformed

    private void BtnSimularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnSimularActionPerformed
        int a = (int) (Math.random()*6)+1;
        int b = (int) (Math.random()*6)+1;
        int res = 0;
        res = a + b;
        this.TxtResultado.setText(res+"");
        
    }//GEN-LAST:event_BtnSimularActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SimLanzamientos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnContinuar;
    private javax.swing.ButtonGroup BtnGroupRta1;
    private javax.swing.ButtonGroup BtnGroupRta2;
    private javax.swing.JButton BtnSimular;
    private javax.swing.JLabel ImagenDado;
    private javax.swing.JMenuItem ItemAbout;
    private javax.swing.JMenuItem ItemSalir;
    private javax.swing.JMenu MenuAcercade;
    private javax.swing.JMenu MenuOpciones;
    private javax.swing.JRadioButton Respuesta1A;
    private javax.swing.JRadioButton Respuesta1B;
    private javax.swing.JRadioButton Respuesta1C;
    private javax.swing.JRadioButton Respuesta1D;
    private javax.swing.JRadioButton Respuesta2A;
    private javax.swing.JRadioButton Respuesta2B;
    private javax.swing.JRadioButton Respuesta2C;
    private javax.swing.JRadioButton Respuesta2D;
    private javax.swing.JLabel TxtExplicacion;
    private javax.swing.JLabel TxtExplicacion2;
    private javax.swing.JLabel TxtExplicacion3;
    private javax.swing.JLabel TxtPregunta1;
    private javax.swing.JLabel TxtPregunta2;
    private javax.swing.JLabel TxtResultado;
    private javax.swing.JLabel TxtSimular;
    private javax.swing.JLabel TxtTitulo;
    private javax.swing.JMenuBar jMenuBar1;
    // End of variables declaration//GEN-END:variables

}
