

package proyecto;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class EjerCodigo2 extends javax.swing.JFrame {


    public EjerCodigo2() {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Exercise 9");
        //grupo botones
        GroupBotones.add(BtnUno);
        GroupBotones.add(BtnDos);
        GroupBotones.add(BtnTres);
        GroupBotones.add(BtnCuatro);
        GroupBotones.add(BtnCinco);  
        //grupo respuestas
        GroupRespuestas.add(BtnRespuesta1);
        GroupRespuestas.add(BtnRespuesta2);
        GroupRespuestas.add(BtnRespuesta3);
        GroupRespuestas.add(BtnRespuesta4);
        
        BtnDos.setEnabled(false);
        BtnTres.setEnabled(false);
        BtnCuatro.setEnabled(false);
        BtnCinco.setEnabled(false);
        
        this.LabelPrueba.setVisible(false);
        this.LabelBinario.setVisible(false);
        //primera fase
        this.BtnRespuesta1.setVisible(false);
        this.BtnRespuesta2.setVisible(false);
        this.BtnRespuesta3.setVisible(false);
        this.BtnRespuesta4.setVisible(false);
        this.BtnResponder.setVisible(false);
        //segunda fase
        this.LabelExplicacion.setVisible(false);
        this.LabelIntegral.setVisible(false);
        this.TxtRespuesta.setVisible(false);
        this.BtnResponder2.setVisible(false);
        //tercera fase
        this.LabelExplicacion2.setVisible(false);
        this.LabelBinario2.setVisible(false);
        this.BtnResponder3.setVisible(false);
        this.TxtRespuesta2.setVisible(false);
        //cuarta fase
        this.LabelExplicacion3.setVisible(false);
        this.TxtRespuesta3.setVisible(false);
        this.BtnContinuar.setEnabled(false);
        this.BtnResponder3.setVisible(false);
        
    }
    

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        GroupBotones = new javax.swing.ButtonGroup();
        GroupRespuestas = new javax.swing.ButtonGroup();
        BtnContinuar = new javax.swing.JButton();
        BtnUno = new javax.swing.JRadioButton();
        BtnDos = new javax.swing.JRadioButton();
        BtnTres = new javax.swing.JRadioButton();
        BtnCuatro = new javax.swing.JRadioButton();
        BtnCinco = new javax.swing.JRadioButton();
        BtnAccion = new javax.swing.JButton();
        LabelPrueba = new javax.swing.JLabel();
        LabelBinario = new javax.swing.JLabel();
        BtnRespuesta1 = new javax.swing.JRadioButton();
        BtnRespuesta2 = new javax.swing.JRadioButton();
        BtnRespuesta3 = new javax.swing.JRadioButton();
        BtnRespuesta4 = new javax.swing.JRadioButton();
        BtnResponder = new javax.swing.JButton();
        LabelExplicacion = new javax.swing.JLabel();
        LabelIntegral = new javax.swing.JLabel();
        TxtRespuesta = new javax.swing.JTextField();
        BtnResponder2 = new javax.swing.JButton();
        LabelExplicacion2 = new javax.swing.JLabel();
        LabelBinario2 = new javax.swing.JLabel();
        TxtRespuesta2 = new javax.swing.JTextField();
        BtnResponder3 = new javax.swing.JButton();
        TxtRespuesta3 = new javax.swing.JTextField();
        LabelExplicacion3 = new javax.swing.JLabel();
        BtnInfo = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        MenuOpciones = new javax.swing.JMenu();
        ItemSalir = new javax.swing.JMenuItem();
        MenuAcercade = new javax.swing.JMenu();
        ItemAbout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        BtnContinuar.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnContinuar.setText("Next");
        BtnContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnContinuarActionPerformed(evt);
            }
        });

        BtnUno.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnUno.setText("Button one");

        BtnDos.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnDos.setText("Button two");

        BtnTres.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnTres.setText("Button three");

        BtnCuatro.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnCuatro.setText("Button four");

        BtnCinco.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnCinco.setText("Button five");

        BtnAccion.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnAccion.setText("Action");
        BtnAccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAccionActionPerformed(evt);
            }
        });

        LabelPrueba.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelPrueba.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LabelPrueba.setText("Very good!, now I want to know: What is this?:");

        LabelBinario.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelBinario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LabelBinario.setText("01010000 01001111 01001111");

        BtnRespuesta1.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnRespuesta1.setText("Three random words");

        BtnRespuesta2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnRespuesta2.setText("Three letters");
        BtnRespuesta2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRespuesta2ActionPerformed(evt);
            }
        });

        BtnRespuesta3.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnRespuesta3.setText("A very big number");

        BtnRespuesta4.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnRespuesta4.setText("Ok, I'm just losing my time");

        BtnResponder.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnResponder.setText("Answer");
        BtnResponder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnResponderActionPerformed(evt);
            }
        });

        LabelExplicacion.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelExplicacion.setText("Well done!, then, do you know the result of... this?");

        LabelIntegral.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelIntegral.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LabelIntegral.setText("Intregral between (2,5) of : x^3+2x dx");

        TxtRespuesta.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N

        BtnResponder2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnResponder2.setText("Answer");
        BtnResponder2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnResponder2ActionPerformed(evt);
            }
        });

        LabelExplicacion2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelExplicacion2.setText("Convert this in a decimal number:");

        LabelBinario2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelBinario2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LabelBinario2.setText("10101010010101010001");

        TxtRespuesta2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        TxtRespuesta2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtRespuesta2ActionPerformed(evt);
            }
        });

        BtnResponder3.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnResponder3.setText("Answer");
        BtnResponder3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnResponder3ActionPerformed(evt);
            }
        });

        TxtRespuesta3.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N

        LabelExplicacion3.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelExplicacion3.setText("Just, take the last result and multiply their digits");

        BtnInfo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Infoicon.png"))); // NOI18N
        BtnInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnInfoActionPerformed(evt);
            }
        });

        MenuOpciones.setText("Options");

        ItemSalir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_MASK));
        ItemSalir.setText("Exit");
        ItemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemSalirActionPerformed(evt);
            }
        });
        MenuOpciones.add(ItemSalir);

        jMenuBar1.add(MenuOpciones);

        MenuAcercade.setText("About of");
        MenuAcercade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuAcercadeActionPerformed(evt);
            }
        });

        ItemAbout.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        ItemAbout.setText("About of");
        ItemAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemAboutActionPerformed(evt);
            }
        });
        MenuAcercade.add(ItemAbout);

        jMenuBar1.add(MenuAcercade);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(TxtRespuesta3, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LabelExplicacion3, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LabelBinario, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(BtnResponder3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(134, 134, 134))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(BtnContinuar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(BtnInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(BtnRespuesta3, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(BtnRespuesta1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(BtnRespuesta2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(BtnUno)
                                        .addGap(18, 18, 18)
                                        .addComponent(BtnDos)
                                        .addGap(18, 18, 18)
                                        .addComponent(BtnTres))
                                    .addComponent(BtnAccion, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(BtnCuatro)
                                .addGap(18, 18, 18)
                                .addComponent(BtnCinco)
                                .addGap(160, 160, 160))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(502, 502, 502)
                                .addComponent(BtnResponder2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(LabelPrueba, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(LabelExplicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(BtnRespuesta4)
                                .addGap(185, 185, 185)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(LabelBinario2, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(LabelExplicacion2, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(392, 392, 392)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(TxtRespuesta, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(LabelIntegral, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(BtnResponder, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(207, 207, 207)
                        .addComponent(TxtRespuesta2, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnUno)
                    .addComponent(BtnDos)
                    .addComponent(BtnTres)
                    .addComponent(BtnCuatro)
                    .addComponent(BtnCinco))
                .addGap(18, 18, 18)
                .addComponent(BtnAccion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelPrueba, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LabelExplicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelBinario)
                    .addComponent(LabelIntegral, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtRespuesta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnRespuesta1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(BtnResponder2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(LabelExplicacion2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(LabelBinario2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17)
                        .addComponent(TxtRespuesta2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BtnRespuesta2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BtnRespuesta3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BtnRespuesta4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BtnResponder)
                        .addGap(17, 17, 17)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelExplicacion3)
                    .addComponent(BtnResponder3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(BtnInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(TxtRespuesta3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(BtnContinuar)))
                .addGap(30, 30, 30))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ItemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemSalirActionPerformed
         System.exit(0);
    }//GEN-LAST:event_ItemSalirActionPerformed

    private void MenuAcercadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuAcercadeActionPerformed

    }//GEN-LAST:event_MenuAcercadeActionPerformed

    private void ItemAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemAboutActionPerformed
         JOptionPane.showMessageDialog(this,"Proyecto creado para nota final POO 2018-3","Acerca de",1);
    }//GEN-LAST:event_ItemAboutActionPerformed

    private void BtnContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnContinuarActionPerformed
          double respuesta = 6*9*7*6*8*1;
          double valori = 0;
          try{
             valori = Double.parseDouble(this.TxtRespuesta3.getText());
          }catch(Exception e){
             JOptionPane.showMessageDialog(this,"There isn't a value","Error",2);
          }
      
          if (respuesta == valori ){
              JOptionPane.showMessageDialog(this,"Very good, you are so smart!!","Congratulations",1);
              EjerSeguirPasos e = new EjerSeguirPasos();
              e.setVisible(true);
              dispose();
              
          }
          else{
              JOptionPane.showMessageDialog(this,"Incorrect answer, Try again","Bad Luck",2); 
          }
          
    }//GEN-LAST:event_BtnContinuarActionPerformed

    private void BtnAccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAccionActionPerformed
       
        if (BtnUno.isSelected()){
            BtnCuatro.setEnabled(true);
            BtnTres.setEnabled(false);
            BtnCinco.setEnabled(false);          
        }
        else{
            if(BtnDos.isSelected()){
                 BtnCuatro.setEnabled(false);
                 BtnTres.setEnabled(true);
                 BtnUno.setEnabled(true);  
                 BtnCinco.setEnabled(false);
            }
            else{
                if(BtnTres.isSelected()){
                     BtnUno.setEnabled(false);
                     BtnDos.setEnabled(false);
                     BtnCuatro.setEnabled(true);
                     BtnTres.setEnabled(false);            
                }
                else{
                    if(BtnCuatro.isSelected()){
                        BtnDos.setEnabled(true);
                        BtnCinco.setEnabled(true);
                        BtnUno.setEnabled(false);   
                    }
                    else{
                        if(BtnCinco.isSelected()){
                            BtnUno.setEnabled(false);
                            BtnDos.setEnabled(false);
                            BtnTres.setEnabled(false);
                            BtnCuatro.setEnabled(false);
                            BtnCinco.setEnabled(false);
                            BtnAccion.setEnabled(false);
                            this.LabelPrueba.setVisible(true);
                            this.LabelBinario.setVisible(true);
                            this.BtnRespuesta1.setVisible(true);
                            this.BtnRespuesta2.setVisible(true);
                            this.BtnRespuesta3.setVisible(true);
                            this.BtnRespuesta4.setVisible(true);
                            this.BtnResponder.setVisible(true);
                        }
                        else{
                            JOptionPane.showMessageDialog(this,"Nothing of the buttons are activated","Error",2); 
                        }
                         
                    }
                }
            }
        }
    }//GEN-LAST:event_BtnAccionActionPerformed

    private void BtnResponderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnResponderActionPerformed
        if(BtnRespuesta2.isSelected()){
            LabelExplicacion.setVisible(true);
            LabelIntegral.setVisible(true);
            TxtRespuesta.setVisible(true);
            BtnResponder2.setVisible(true);
            
            BtnResponder.setEnabled(false);
            BtnRespuesta1.setEnabled(false);
            BtnRespuesta2.setEnabled(false);
            BtnRespuesta3.setEnabled(false);
            BtnRespuesta4.setEnabled(false);
            
            
            
        }
        else{
            JOptionPane.showMessageDialog(this, "Incorrect answer, try again", "Bad Luck", 2);
        }
    }//GEN-LAST:event_BtnResponderActionPerformed

    private void BtnResponder2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnResponder2ActionPerformed
        double resintegral = 0;
        double valori = 0;
        try{
             valori = Double.parseDouble(this.TxtRespuesta.getText());  
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(this,"There isn't a value","Error",2);      
        }
     
        resintegral = ((Math.pow(5,4))/4)+(2*(Math.pow(5,2))-((Math.pow(2,4))/4)+(2*(Math.pow(2,2))));
        if (valori == resintegral){
            this.LabelExplicacion2.setVisible(true);
            this.LabelBinario2.setVisible(true);
            this.TxtRespuesta2.setVisible(true);
            this.BtnResponder3.setVisible(true);
            TxtRespuesta.setEnabled(false);
            BtnResponder2.setEnabled(false);
        }
        else{
            JOptionPane.showMessageDialog(this,"Incorrect answer, Try again","Bad Luck",2);
        }
        

        
    }//GEN-LAST:event_BtnResponder2ActionPerformed

    private void BtnRespuesta2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRespuesta2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnRespuesta2ActionPerformed

    private void TxtRespuesta2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtRespuesta2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtRespuesta2ActionPerformed

    private void BtnResponder3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnResponder3ActionPerformed
        double respuesta = 697681; 
        double valori = 0;
        
        try{
         valori  = Double.parseDouble(this.TxtRespuesta2.getText()); 
        }catch (Exception e){
            JOptionPane.showMessageDialog(this,"There isn't a value","Error",2);
        }
 
        if (respuesta == valori){
            this.LabelExplicacion3.setVisible(true);
            this.TxtRespuesta3.setVisible(true);
            this.TxtRespuesta2.setEnabled(false);
            this.BtnResponder3.setEnabled(false);
            this.BtnContinuar.setEnabled(true);
        }
        else{
            JOptionPane.showMessageDialog(this,"Incorrect answer, Try again","Bad Luck",2);     
        }
    }//GEN-LAST:event_BtnResponder3ActionPerformed

    private void BtnInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnInfoActionPerformed
        JOptionPane.showMessageDialog(this,"No hints for you, just remember how do you convert a binary number","Something else",1);
    }//GEN-LAST:event_BtnInfoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EjerCodigo2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EjerCodigo2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EjerCodigo2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EjerCodigo2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EjerCodigo2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAccion;
    private javax.swing.JRadioButton BtnCinco;
    private javax.swing.JButton BtnContinuar;
    private javax.swing.JRadioButton BtnCuatro;
    private javax.swing.JRadioButton BtnDos;
    private javax.swing.JButton BtnInfo;
    private javax.swing.JButton BtnResponder;
    private javax.swing.JButton BtnResponder2;
    private javax.swing.JButton BtnResponder3;
    private javax.swing.JRadioButton BtnRespuesta1;
    private javax.swing.JRadioButton BtnRespuesta2;
    private javax.swing.JRadioButton BtnRespuesta3;
    private javax.swing.JRadioButton BtnRespuesta4;
    private javax.swing.JRadioButton BtnTres;
    private javax.swing.JRadioButton BtnUno;
    private javax.swing.ButtonGroup GroupBotones;
    private javax.swing.ButtonGroup GroupRespuestas;
    private javax.swing.JMenuItem ItemAbout;
    private javax.swing.JMenuItem ItemSalir;
    private javax.swing.JLabel LabelBinario;
    private javax.swing.JLabel LabelBinario2;
    private javax.swing.JLabel LabelExplicacion;
    private javax.swing.JLabel LabelExplicacion2;
    private javax.swing.JLabel LabelExplicacion3;
    private javax.swing.JLabel LabelIntegral;
    private javax.swing.JLabel LabelPrueba;
    private javax.swing.JMenu MenuAcercade;
    private javax.swing.JMenu MenuOpciones;
    private javax.swing.JTextField TxtRespuesta;
    private javax.swing.JTextField TxtRespuesta2;
    private javax.swing.JTextField TxtRespuesta3;
    private javax.swing.JMenuBar jMenuBar1;
    // End of variables declaration//GEN-END:variables

}
