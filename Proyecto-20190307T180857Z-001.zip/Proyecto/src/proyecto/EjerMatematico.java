

package proyecto;

import javax.swing.JOptionPane;


public class EjerMatematico extends javax.swing.JFrame {


    public EjerMatematico() {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Ejercicio 6");
        BtnGroupRta1.add(Respuesta1A);
        BtnGroupRta1.add(Respuesta1B);
        BtnGroupRta1.add(Respuesta1C);
        BtnGroupRta1.add(Respuesta1D);
        BtnGroupRta2.add(Respuesta2A);
        BtnGroupRta2.add(Respuesta2B);
        BtnGroupRta2.add(Respuesta2C);
        BtnGroupRta2.add(Respuesta2D);    
    }
    

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BtnGroupRta1 = new javax.swing.ButtonGroup();
        BtnGroupRta2 = new javax.swing.ButtonGroup();
        BtnContinuar = new javax.swing.JButton();
        LabelExplicacion = new javax.swing.JLabel();
        LabelIcon = new javax.swing.JLabel();
        LabelEcuacionE = new javax.swing.JLabel();
        LabelEcuacionC = new javax.swing.JLabel();
        LabelEcuacionF = new javax.swing.JLabel();
        LabelExplicacion2 = new javax.swing.JLabel();
        LabelTitulo = new javax.swing.JLabel();
        LabelMayor = new javax.swing.JLabel();
        LabelMprop = new javax.swing.JLabel();
        Respuesta1A = new javax.swing.JRadioButton();
        Respuesta1B = new javax.swing.JRadioButton();
        Respuesta1C = new javax.swing.JRadioButton();
        Respuesta1D = new javax.swing.JRadioButton();
        Respuesta2A = new javax.swing.JRadioButton();
        Respuesta2B = new javax.swing.JRadioButton();
        Respuesta2C = new javax.swing.JRadioButton();
        Respuesta2D = new javax.swing.JRadioButton();
        TxtValor1 = new javax.swing.JTextField();
        TxtValor2 = new javax.swing.JTextField();
        TxtOperador = new javax.swing.JTextField();
        BtnCalcular = new javax.swing.JButton();
        LabelResultado = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        MenuOpciones = new javax.swing.JMenu();
        ItemSalir = new javax.swing.JMenuItem();
        MenuAcercade = new javax.swing.JMenu();
        ItemAbout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        BtnContinuar.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnContinuar.setText("Next");
        BtnContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnContinuarActionPerformed(evt);
            }
        });

        LabelExplicacion.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelExplicacion.setText("There are 7 spaces in a circle, each one are 1/7 (ex. C, E and F)");

        LabelIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Circleicon.jpg"))); // NOI18N

        LabelEcuacionE.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelEcuacionE.setText("E: (A*C) + D - B");

        LabelEcuacionC.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelEcuacionC.setText("C: A/D +6");

        LabelEcuacionF.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelEcuacionF.setText("F: (E^2)-(A^2)+(B^2)/ C + D");

        LabelExplicacion2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelExplicacion2.setText("Which of these (C,E,F) are bigger, what have biggest proportion?");

        LabelTitulo.setFont(new java.awt.Font("Sitka Small", 3, 12)); // NOI18N
        LabelTitulo.setText("Mathematic Exercise");

        LabelMayor.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelMayor.setText("Biggest");

        LabelMprop.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelMprop.setText("Biggest Proportion");

        Respuesta1A.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta1A.setText("C");

        Respuesta1B.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta1B.setText("F");

        Respuesta1C.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta1C.setText("E");

        Respuesta1D.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta1D.setText("Nothing of above");

        Respuesta2A.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta2A.setText("F");

        Respuesta2B.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta2B.setText("E");

        Respuesta2C.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta2C.setText("C");

        Respuesta2D.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        Respuesta2D.setText("Nothing of above");

        TxtValor1.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N

        TxtValor2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N

        TxtOperador.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N

        BtnCalcular.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnCalcular.setText("Calculate");
        BtnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCalcularActionPerformed(evt);
            }
        });

        LabelResultado.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N

        MenuOpciones.setText("Options");

        ItemSalir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_MASK));
        ItemSalir.setText("Exit");
        ItemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemSalirActionPerformed(evt);
            }
        });
        MenuOpciones.add(ItemSalir);

        jMenuBar1.add(MenuOpciones);

        MenuAcercade.setText("About of");
        MenuAcercade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuAcercadeActionPerformed(evt);
            }
        });

        ItemAbout.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        ItemAbout.setText("About of");
        ItemAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemAboutActionPerformed(evt);
            }
        });
        MenuAcercade.add(ItemAbout);

        jMenuBar1.add(MenuAcercade);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LabelExplicacion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(LabelIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelEcuacionF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(LabelEcuacionC, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(LabelEcuacionE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(LabelTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(LabelExplicacion2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(LabelMayor, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Respuesta1A)
                            .addComponent(Respuesta1B)
                            .addComponent(Respuesta1C)
                            .addComponent(Respuesta1D))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Respuesta2A)
                            .addComponent(Respuesta2C)
                            .addComponent(Respuesta2D)
                            .addComponent(LabelMprop, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Respuesta2B))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addComponent(BtnContinuar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtnCalcular, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(TxtValor1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TxtValor2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(TxtOperador, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LabelResultado, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LabelExplicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(LabelEcuacionC, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(LabelEcuacionE, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(LabelEcuacionF, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(LabelIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LabelExplicacion2, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelMayor)
                    .addComponent(LabelMprop))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(TxtValor1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(TxtValor2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Respuesta2A, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(Respuesta1A, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(TxtOperador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Respuesta1B, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Respuesta2B, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Respuesta1C)
                            .addComponent(Respuesta2C))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Respuesta1D)
                            .addComponent(Respuesta2D)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(BtnCalcular)))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtnContinuar)
                    .addComponent(LabelResultado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ItemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemSalirActionPerformed
         System.exit(0);
    }//GEN-LAST:event_ItemSalirActionPerformed

    private void MenuAcercadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuAcercadeActionPerformed

    }//GEN-LAST:event_MenuAcercadeActionPerformed

    private void ItemAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemAboutActionPerformed
         JOptionPane.showMessageDialog(this,"Project created for Final note of POO 2018-3","About of",1);
    }//GEN-LAST:event_ItemAboutActionPerformed

    private void BtnContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnContinuarActionPerformed
         if (Respuesta1A.isSelected() && Respuesta2C.isSelected()){
            JOptionPane.showMessageDialog(this,"Correct Answer: the value C is the biggest value and it has the biggest proportion","Congratulations",1);
            EjerFormulas e = new EjerFormulas();
            e.setVisible(true);
            dispose();            
         }
         else{
             JOptionPane.showMessageDialog(this,"Incorrect Answer: Try again","Bad Luck",1);
         }
    }//GEN-LAST:event_BtnContinuarActionPerformed

    private void BtnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCalcularActionPerformed
        try{
        double a = Double.parseDouble(this.TxtValor1.getText());
        double b = Double.parseDouble(this.TxtValor2.getText());
        String op = this.TxtOperador.getText();
        double res = 0;
        if (op.equals("+")){
            res = a + b;            
        }
        else{
            if (op.equals("-")){
                res = a - b;
            }
            else{
                if(op.equals("*")){
                    res = a * b;
                }
                else{
                    if(op.equals("/")){
                        try{
                            res = a / b;   
                        }catch(Exception e){
                            JOptionPane.showMessageDialog(this,"Possible division by 0 in the operation","Warning",0);
                        }

                    }
                    else{
                        if(this.TxtValor1.getText().equals("") || this.TxtValor2.getText().equals("") || this.TxtOperador.equals("")){
                             JOptionPane.showMessageDialog(this,"There isn't any operator to calculate them","Warning",2);  
                        }        
                    }
                }
            }
        }
        this.LabelResultado.setText(res+"");     
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(this,"There isn't any value or operator to calculate","Warning",2);
        }
    
    }//GEN-LAST:event_BtnCalcularActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EjerMatematico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EjerMatematico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EjerMatematico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EjerMatematico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EjerMatematico().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnCalcular;
    private javax.swing.JButton BtnContinuar;
    private javax.swing.ButtonGroup BtnGroupRta1;
    private javax.swing.ButtonGroup BtnGroupRta2;
    private javax.swing.JMenuItem ItemAbout;
    private javax.swing.JMenuItem ItemSalir;
    private javax.swing.JLabel LabelEcuacionC;
    private javax.swing.JLabel LabelEcuacionE;
    private javax.swing.JLabel LabelEcuacionF;
    private javax.swing.JLabel LabelExplicacion;
    private javax.swing.JLabel LabelExplicacion2;
    private javax.swing.JLabel LabelIcon;
    private javax.swing.JLabel LabelMayor;
    private javax.swing.JLabel LabelMprop;
    private javax.swing.JLabel LabelResultado;
    private javax.swing.JLabel LabelTitulo;
    private javax.swing.JMenu MenuAcercade;
    private javax.swing.JMenu MenuOpciones;
    private javax.swing.JRadioButton Respuesta1A;
    private javax.swing.JRadioButton Respuesta1B;
    private javax.swing.JRadioButton Respuesta1C;
    private javax.swing.JRadioButton Respuesta1D;
    private javax.swing.JRadioButton Respuesta2A;
    private javax.swing.JRadioButton Respuesta2B;
    private javax.swing.JRadioButton Respuesta2C;
    private javax.swing.JRadioButton Respuesta2D;
    private javax.swing.JTextField TxtOperador;
    private javax.swing.JTextField TxtValor1;
    private javax.swing.JTextField TxtValor2;
    private javax.swing.JMenuBar jMenuBar1;
    // End of variables declaration//GEN-END:variables

}
