

package proyecto;

import java.awt.Color;
import javax.swing.JOptionPane;


public class EjerCodigo1 extends javax.swing.JFrame {


    public EjerCodigo1() {
        initComponents();

        setLocationRelativeTo(null);
        setTitle("Ejercicio 8");
        this.AreaCodigo1.setEditable(false);
        this.AreaCodigo2.setEditable(false);
        this.AreaCodigo3.setEditable(false);
        this.AreaCodigo1.setBackground(new Color(204,204,204));
        this.AreaCodigo2.setBackground(new Color(204,204,204));
        this.AreaCodigo3.setBackground(new Color(204,204,204));

        
        
    }
    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BtnContinuar = new javax.swing.JButton();
        LabelTitulo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        AreaCodigo1 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        AreaCodigo2 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        AreaCodigo3 = new javax.swing.JTextArea();
        LabelExplicacion = new javax.swing.JLabel();
        LabelRespuesta1 = new javax.swing.JLabel();
        LabelRespuesta2 = new javax.swing.JLabel();
        LabelRespuesta3 = new javax.swing.JLabel();
        TxtRespuesta1 = new javax.swing.JTextField();
        TxtRespuesta2 = new javax.swing.JTextField();
        TxtRespuesta3 = new javax.swing.JTextField();
        CheckListo = new javax.swing.JCheckBox();
        LabelIcon = new javax.swing.JLabel();
        BtnInfo = new javax.swing.JButton();
        BtnPista = new javax.swing.JButton();
        LabelPista = new javax.swing.JLabel();
        LabelExplicacion2 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        MenuOpciones = new javax.swing.JMenu();
        ItemSalir = new javax.swing.JMenuItem();
        MenuAcercade = new javax.swing.JMenu();
        ItemAbout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        BtnContinuar.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnContinuar.setText("Next");
        BtnContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnContinuarActionPerformed(evt);
            }
        });

        LabelTitulo.setFont(new java.awt.Font("Sitka Small", 3, 12)); // NOI18N
        LabelTitulo.setText("Code Exercise I");

        AreaCodigo1.setColumns(20);
        AreaCodigo1.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        AreaCodigo1.setRows(5);
        AreaCodigo1.setText("*Prime number whose digits add results:\n14, between 367 and 409.\n*This, minus the 12° Fibonacci series number:\n*The result is the first number.");
        jScrollPane1.setViewportView(AreaCodigo1);

        AreaCodigo2.setColumns(20);
        AreaCodigo2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        AreaCodigo2.setRows(5);
        AreaCodigo2.setText("*The result of the next integral:\nintegral between [3,25]:\nx^3+2x^2 dx\n*The result of this divided in 100.\n*Take the first three decimal numbers:\n*The result is the second number.\n");
        jScrollPane2.setViewportView(AreaCodigo2);

        AreaCodigo3.setColumns(20);
        AreaCodigo3.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        AreaCodigo3.setRows(5);
        AreaCodigo3.setText("*Number whose divisors are [1,2,3,6], also, that number is\nan amount of guys very famous in the biblic stories.\n*Combine this with the first letter of the Capital of Paraguay:\n*Then, write that as a hexadecimal value (ex. 23F).\n*Finally Convert it.\n*The result is the third number");
        jScrollPane3.setViewportView(AreaCodigo3);

        LabelExplicacion.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelExplicacion.setText("You must find three integer numbers to complete this exercise, each one has three digits.");

        LabelRespuesta1.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelRespuesta1.setText("Your first answer:");

        LabelRespuesta2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelRespuesta2.setText("Your second answer:");

        LabelRespuesta3.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelRespuesta3.setText("Your third answer:");

        TxtRespuesta1.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        TxtRespuesta1.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        TxtRespuesta2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        TxtRespuesta2.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        TxtRespuesta3.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        TxtRespuesta3.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        CheckListo.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        CheckListo.setText("I am ready");

        LabelIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LabelIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/CodigoIcon.png"))); // NOI18N
        LabelIcon.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);

        BtnInfo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Infoicon.png"))); // NOI18N
        BtnInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnInfoActionPerformed(evt);
            }
        });

        BtnPista.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        BtnPista.setText("Something");
        BtnPista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnPistaActionPerformed(evt);
            }
        });

        LabelPista.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelPista.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        LabelExplicacion2.setFont(new java.awt.Font("Sitka Small", 2, 12)); // NOI18N
        LabelExplicacion2.setText("You must use your mathematical concepts to solve this exercise");

        MenuOpciones.setText("Options");

        ItemSalir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_MASK));
        ItemSalir.setText("Exit");
        ItemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemSalirActionPerformed(evt);
            }
        });
        MenuOpciones.add(ItemSalir);

        jMenuBar1.add(MenuOpciones);

        MenuAcercade.setText("About of");
        MenuAcercade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuAcercadeActionPerformed(evt);
            }
        });

        ItemAbout.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        ItemAbout.setText("About of");
        ItemAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemAboutActionPerformed(evt);
            }
        });
        MenuAcercade.add(ItemAbout);

        jMenuBar1.add(MenuAcercade);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(BtnInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(260, 260, 260)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(CheckListo)
                                .addGap(41, 41, 41)
                                .addComponent(LabelPista, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(BtnContinuar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(BtnPista)
                                .addGap(224, 224, 224))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(TxtRespuesta1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(LabelRespuesta1, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(LabelRespuesta2, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TxtRespuesta2, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 392, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(LabelRespuesta3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 392, Short.MAX_VALUE)
                                .addComponent(TxtRespuesta3, javax.swing.GroupLayout.Alignment.LEADING)))
                        .addGap(20, 20, 20))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(LabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(160, 160, 160))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(LabelExplicacion2, javax.swing.GroupLayout.PREFERRED_SIZE, 545, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(LabelExplicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 545, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)))
                        .addComponent(LabelIcon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(LabelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(LabelExplicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(LabelExplicacion2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(LabelIcon))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelRespuesta1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(LabelRespuesta2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(LabelRespuesta3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtRespuesta2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxtRespuesta1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TxtRespuesta3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CheckListo)
                            .addComponent(LabelPista, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(BtnPista)
                            .addComponent(BtnContinuar)))
                    .addComponent(BtnInfo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ItemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemSalirActionPerformed
         System.exit(0);
    }//GEN-LAST:event_ItemSalirActionPerformed

    private void MenuAcercadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuAcercadeActionPerformed

    }//GEN-LAST:event_MenuAcercadeActionPerformed

    private void ItemAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemAboutActionPerformed
         JOptionPane.showMessageDialog(this,"Project created for final note for POO 2018-3","About of",1);
    }//GEN-LAST:event_ItemAboutActionPerformed

    private void BtnContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnContinuarActionPerformed
           String r1 = this.TxtRespuesta1.getText();
           String r2 = this.TxtRespuesta2.getText();
           String r3 = this.TxtRespuesta3.getText();
           
           if(r1.equals("239") && r2.equals("346") && r3.equals("298") && CheckListo.isSelected()){
               JOptionPane.showMessageDialog(this,"Yes, those values are correct, you are so good at math","Congratulations",1);
               MinijuegoOperaciones e = new MinijuegoOperaciones();
               e.setVisible(true);
               dispose();
           }
           else{
               JOptionPane.showMessageDialog(this,"No, any of those values are incorrect, or you don't select the check button","Bad Luck",2);
               JOptionPane.showMessageDialog(this,"Try Again","Bad Luck",2);
           }
           
    }//GEN-LAST:event_BtnContinuarActionPerformed

    private void BtnPistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnPistaActionPerformed
       this.LabelPista.setText("Remember how do you obtain the value of Fibonacci series (An-1+An)");
    }//GEN-LAST:event_BtnPistaActionPerformed

    private void BtnInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnInfoActionPerformed
       JOptionPane.showMessageDialog(this,"Maybe, you should use external actions to complete this","Not a useful information",1);
    }//GEN-LAST:event_BtnInfoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EjerCodigo1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EjerCodigo1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EjerCodigo1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EjerCodigo1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EjerCodigo1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AreaCodigo1;
    private javax.swing.JTextArea AreaCodigo2;
    private javax.swing.JTextArea AreaCodigo3;
    private javax.swing.JButton BtnContinuar;
    private javax.swing.JButton BtnInfo;
    private javax.swing.JButton BtnPista;
    private javax.swing.JCheckBox CheckListo;
    private javax.swing.JMenuItem ItemAbout;
    private javax.swing.JMenuItem ItemSalir;
    private javax.swing.JLabel LabelExplicacion;
    private javax.swing.JLabel LabelExplicacion2;
    private javax.swing.JLabel LabelIcon;
    private javax.swing.JLabel LabelPista;
    private javax.swing.JLabel LabelRespuesta1;
    private javax.swing.JLabel LabelRespuesta2;
    private javax.swing.JLabel LabelRespuesta3;
    private javax.swing.JLabel LabelTitulo;
    private javax.swing.JMenu MenuAcercade;
    private javax.swing.JMenu MenuOpciones;
    private javax.swing.JTextField TxtRespuesta1;
    private javax.swing.JTextField TxtRespuesta2;
    private javax.swing.JTextField TxtRespuesta3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    // End of variables declaration//GEN-END:variables

}
