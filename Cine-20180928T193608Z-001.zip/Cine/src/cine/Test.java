package cine;
public class Test {
        public static void main(String[] args) {
            Menu men = new Menu();
            men.menu();
        }
}
