package cine;

public class Llenar extends Personas{
    private String [][] Salall =  new String [8][9]; 
    
    public Llenar(){
        for(int i = 0;i<8; i++){
            for(int j = 0; j<9; j++){
                this.Salall[i][j] = "A";   
            }
            
        }
    }
    public String[][] GetSALALL(){
        return this.Salall;
    }
    public void SetSALALL(String sal[][]){
        this.Salall = sal;
    } 
    
    public Boolean ValidacionEntrada(double Dinero, double Edad, double RestEdad){
         Sala sal = new Sala();
         Pelicula r=new Pelicula();

         if (Edad>=RestEdad){
            if(sal.GetPRECIO()<=Dinero){
                return true;
                }
         }else{
            return false;
         }
         return false;
    }
    
    public void Pos(){
        Personas per = new Personas();
        Pelicula pel = new Pelicula();
        pel.Asignar();
        boolean segundo=false;
        int cont=0;
        
        for (int i=0 ;i<8;i++){
            for (int j=0;j<9;j++){
                Menu reserva=new Menu();
                if (i==reserva.GetRESF1() && j==reserva.GetRESC1()){
                    Salall[i][j]="R";
                }
                if (i==reserva.GetRESF2() && j==reserva.GetRESC2()){
                    Salall[i][j]="R";
                }
                if (i==reserva.GetRESF3() && j==reserva.GetRESC3()){
                    Salall[i][j]="R";
                }
                if (i==reserva.GetRESF4() && j==reserva.GetRESC4()){
                    Salall[i][j]="R";
                }
            }
        }
        for(int i = 0; i<8;i++){
            for (int j = 0;j<9;j++){
               Sala k=new Sala();
               double f=per.RandomDinero();
               int a=per.GetEDAD();
               double q=pel.GetRESTEDAD();
               per.Random();
                   int x= (int) (Math.random()*8);
                   int y= (int) (Math.random()*9);
               if (ValidacionEntrada(f,a,q)){
                   boolean verf=false;
                if (Salall[x][y]=="A"){
                    Salall[x][y]=per.GetNOMBRE();
                    System.out.print("|"+"O"+"|");
                    verf=true;
                    cont++;
                }
                else{
                   verf=false;  
                   while (verf==false){
                   x= (int) (Math.random()*8);
                   y= (int) (Math.random()*9);
                   if (Salall[x][y]=="A"){
                       Salall[x][y]=per.GetNOMBRE();
                       System.out.print("|"+"O"+"|");
                       verf=true;
                       cont++;
                  }
                 } 
                }
                if (Salall[x][y]=="R"){
                    System.out.println("|R|");
                }
               }
               else{
                 per.Random();
                 System.out.print("| |");
               }
                try {
                  Thread.sleep (0);
                } 
                catch (InterruptedException ex) {
                }
            }
            System.out.println(" ");                    
        }
        if (cont!=72){
             System.out.println("");
             System.out.println("Como la sala no esta llena, se procederá a llenar los asientos restantes con otros espectadores");  
             System.out.println("");
        }
        else{
            System.out.println("");
            System.out.println("La sala ya se encuentra llena");
            System.out.println("");
        }

        cont=0;
        
        while(segundo==false){
            if (cont!=72){
            for(int i = 0; i<8;i++){
            for (int j = 0;j<9;j++){
                if (Salall[i][j]!="A" || Salall [i][j]!="R"){
                    System.out.print("|"+"O"+"|");
                    cont++;
                }
                else{
                  boolean verf2=false;
                  per.Random();
                  double f=per.RandomDinero();
                  int a=per.GetEDAD();
                  double q=pel.GetRESTEDAD();
                    if (ValidacionEntrada(f,a,q)){
                      Salall[i][j]=per.GetNOMBRE();
                      System.out.print("|"+"O"+"|");
                      verf2=true; 
                      cont++;
                      }
                    else{
                      verf2=false;  
                      while (verf2==false){
                        Salall[i][j]=per.GetNOMBRE();
                        System.out.print("|"+"O"+"|");
                        verf2=true;
                    }
                   cont++;
                }
            }
            try {
              Thread.sleep (0);
            } 
            catch (InterruptedException ex) {
            }
            }
              System.out.println(" ");  
            }

        if (cont==72){
            segundo=true;
            System.out.println("");
            System.out.println("La sala ya se encuentra llena");
            System.out.println("");
        }
        else{
            segundo=false;
            System.out.println("");
            System.out.println("La sala aun no se encuentra llena, se procederá a repetir el ciclo anterior");
            System.out.println("");
        }
            }
            else{
                segundo=true;
                System.out.println("");
                System.out.println("La sala ya se encuentra llena");
                System.out.println("");
            }                   
        }  
        int lug=1;
        System.out.println("Espectadores:");
        System.out.println("");
        for (int i=0;i<8;i++){
            for (int j=0;j<9;j++){
                System.out.println("Espectador "+ lug +": "+Salall[i][j]);
                lug++;
                try {
                  Thread.sleep (0);
                } 
                catch (InterruptedException ex) {
                }
            }
        }

    }
}

 

