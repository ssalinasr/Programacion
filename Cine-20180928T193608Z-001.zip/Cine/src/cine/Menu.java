package cine;

import java.util.Scanner;

public class Menu {
    
    private int reserva;
    private int ResAF1;
    private int ResAC1;
    private int ResAF2;
    private int ResAC2;
    private int ResAF3;
    private int ResAC3;
    private int ResAF4;
    private int ResAC4;

    
    public Menu(){
        reserva=0;
    }
    
    public void SetRESERVA(int x){
        reserva= x;
    }
    
    public int GetRESERVA(){
        return reserva;
    }
    
    public void SetRESF1(int x){
        ResAF1= x;
    }
    
    public int GetRESF1(){
        return ResAF1;
    }
    
        public void SetRESC1(int x){
        ResAC1= x;
    }
    
    public int GetRESC1(){
        return ResAC1;
    }
    
        public void SetRESF2(int x){
        ResAF2= x;
    }
    
    public int GetRESF2(){
        return ResAF2;
    }
    
        public void SetRESC2(int x){
        ResAC2= x;
    }
    
    public int GetRESC2(){
        return ResAC2;
    }
    
        public void SetRESF3(int x){
        ResAF3= x;
    }
    
    public int GetRESF3(){
        return ResAF3;
    }
        public void SetRESC3(int x){
        ResAC3= x;
    }
    
    public int GetRESC3(){
        return ResAC3;
    }
        public void SetRESF4(int x){
        ResAF4= x;
    }
    
    public int GetRESF4(){
        return ResAF4;
    }
        public void SetRESC4(int x){
        ResAC4= x;
    }
    
    public int GetRESC4(){
        return ResAC4;
    }
    
    
    public boolean eleccion (int e){
        if (e==0){
            return false;
        }
        else{
            return true;
        }
    }
    
    public int PedirDato(){
        int o;
        Scanner k=new Scanner(System.in);
        o=k.nextInt();  
        return o;
    }
    
    public String PedirPosicion(){
        String a;
        Scanner q=new Scanner(System.in);
        a=q.nextLine();
        return a;   
    }
    
    
    public void menu(){
        int a;
        System.out.println("Desea reservar asientos?: (0=no, 1=si)");
        a=PedirDato();
        if (eleccion(a)){
            System.out.println("Cuantos?:(no puede reservar mas de cuatro)");
            int b= PedirDato();
            
            String posAF;
            String posAC;
            String posBF;
            String posBC;
            String posCF;
            String posCC;
            String posDF;
            String posDC;
            
            int posaf1=0;
            int posac1=0;
            int posaf2=0;
            int posac2=0;
            int posaf3=0;
            int posac3=0;
            int posaf4=0;
            int posac4=0;
            
            if (b>0 && b<5){
              this.SetRESERVA(b);
              System.out.println("Cuales?: Especifique fila y columna");
              switch(b){
                  case 1:
                      System.out.println("Fila");
                      posAF=PedirPosicion();
                      
                      posaf1=Integer.parseInt(posAF);
                      System.out.println("Columna");
                      posAC=PedirPosicion();
                      switch (posAC){
                        case "A":
                              posAC="1";
                              break;
                        case "B":
                              posAC="2";
                              break;
                        case "C":
                              posAC="3";
                              break;
                        case "D":
                              posAC="4";
                              break;
                        case "E":
                              posAC="5";
                              break;
                        case "F":
                              posAC="6";
                              break;
                        case "G":
                              posAC="7";
                              break;
                        case "H":
                              posAC="8";
                              break;
                        case "I":
                              posAC="9";
                              break;
                      }
                      posac1=Integer.parseInt(posAC);
                      break;
                  case 2:
                      System.out.println("Fila");
                      posAF=PedirPosicion();
                      posaf1=Integer.parseInt(posAF);
                      System.out.println("Columna");
                      posAC=PedirPosicion();
                      switch (posAC){
                        case "A":
                              posAC="1";
                              break;
                        case "B":
                              posAC="2";
                              break;
                        case "C":
                              posAC="3";
                              break;
                        case "D":
                              posAC="4";
                              break;
                        case "E":
                              posAC="5";
                              break;
                        case "F":
                              posAC="6";
                              break;
                        case "G":
                              posAC="7";
                              break;
                        case "H":
                              posAC="8";
                              break;
                        case "I":
                              posAC="9";
                              break;
                      }
                      posac1=Integer.parseInt(posAC);
                      System.out.println("Fila");
                      posBF=PedirPosicion();
                      posaf2=Integer.parseInt(posBF);
                      System.out.println("Columna");
                      posBC=PedirPosicion();
                      switch (posBC){
                        case "A":
                              posBC="1";
                              break;
                        case "B":
                              posBC="2";
                              break;
                        case "C":
                              posBC="3";
                              break;
                        case "D":
                              posBC="4";
                              break;
                        case "E":
                              posBC="5";
                              break;
                        case "F":
                              posBC="6";
                              break;
                        case "G":
                              posBC="7";
                              break;
                        case "H":
                              posBC="8";
                              break;
                        case "I":
                              posBC="9";
                              break;
                      }
                      posac2=Integer.parseInt(posBC);
                      break;
                  case 3:
                     System.out.println("Fila");
                      posAF=PedirPosicion();
                      posaf1=Integer.parseInt(posAF);
                      System.out.println("Columna");
                      posAC=PedirPosicion();
                      switch (posAC){
                        case "A":
                              posAC="1";
                              break;
                        case "B":
                              posAC="2";
                              break;
                        case "C":
                              posAC="3";
                              break;
                        case "D":
                              posAC="4";
                              break;
                        case "E":
                              posAC="5";
                              break;
                        case "F":
                              posAC="6";
                              break;
                        case "G":
                              posAC="7";
                              break;
                        case "H":
                              posAC="8";
                              break;
                        case "I":
                              posAC="9";
                              break;
                      }
                      posac1=Integer.parseInt(posAC);
                      System.out.println("Fila");
                      posBF=PedirPosicion();
                      posaf2=Integer.parseInt(posBF);
                      System.out.println("Columna");
                      posBC=PedirPosicion();
                      switch (posBC){
                        case "A":
                              posBC="1";
                              break;
                        case "B":
                              posBC="2";
                              break;
                        case "C":
                              posBC="3";
                              break;
                        case "D":
                              posBC="4";
                              break;
                        case "E":
                              posBC="5";
                              break;
                        case "F":
                              posBC="6";
                              break;
                        case "G":
                              posBC="7";
                              break;
                        case "H":
                              posBC="8";
                              break;
                        case "I":
                              posBC="9";
                              break;
                      }
                      posac2=Integer.parseInt(posBC);
                      System.out.println("Fila");
                      posCF=PedirPosicion();
                      posaf3=Integer.parseInt(posCF);
                      System.out.println("Columna");
                      posCC=PedirPosicion();
                      switch (posCC){
                        case "A":
                              posCC="1";
                              break;
                        case "B":
                              posCC="2";
                              break;
                        case "C":
                              posCC="3";
                              break;
                        case "D":
                              posCC="4";
                              break;
                        case "E":
                              posCC="5";
                              break;
                        case "F":
                              posCC="6";
                              break;
                        case "G":
                              posCC="7";
                              break;
                        case "H":
                              posCC="8";
                              break;
                        case "I":
                              posCC="9";
                              break;
                      }
                      posac3=Integer.parseInt(posCC);
                      break;
                      
                  case 4:
                      System.out.println("Fila");
                      posAF=PedirPosicion();
                      posaf1=Integer.parseInt(posAF);
                      System.out.println("Columna");
                      posAC=PedirPosicion();
                    switch (posAC){
                        case "A":
                              posAC="1";
                              break;
                        case "B":
                              posAC="2";
                              break;
                        case "C":
                              posAC="3";
                              break;
                        case "D":
                              posAC="4";
                              break;
                        case "E":
                              posAC="5";
                              break;
                        case "F":
                              posAC="6";
                              break;
                        case "G":
                              posAC="7";
                              break;
                        case "H":
                              posAC="8";
                              break;
                        case "I":
                              posAC="9";
                              break;
                      }
                      posac1=Integer.parseInt(posAC);
                      System.out.println("Fila");
                      posBF=PedirPosicion();
                      posaf2=Integer.parseInt(posBF);
                      System.out.println("Columna");
                      posBC=PedirPosicion();
                      switch (posBC){
                        case "A":
                              posBC="1";
                              break;
                        case "B":
                              posBC="2";
                              break;
                        case "C":
                              posBC="3";
                              break;
                        case "D":
                              posBC="4";
                              break;
                        case "E":
                              posBC="5";
                              break;
                        case "F":
                              posBC="6";
                              break;
                        case "G":
                              posBC="7";
                              break;
                        case "H":
                              posBC="8";
                              break;
                        case "I":
                              posBC="9";
                              break;
                      }
                      posac2=Integer.parseInt(posBC);
                      System.out.println("Fila");
                      posCF=PedirPosicion();
                      posaf3=Integer.parseInt(posCF);
                      System.out.println("Columna");
                      posCC=PedirPosicion();
                      switch (posCC){
                        case "A":
                              posCC="1";
                              break;
                        case "B":
                              posCC="2";
                              break;
                        case "C":
                              posCC="3";
                              break;
                        case "D":
                              posCC="4";
                              break;
                        case "E":
                              posCC="5";
                              break;
                        case "F":
                              posCC="6";
                              break;
                        case "G":
                              posCC="7";
                              break;
                        case "H":
                              posCC="8";
                              break;
                        case "I":
                              posCC="9";
                              break;
                      }
                      posac3=Integer.parseInt(posCC);
                      System.out.println("Fila");
                      posDF=PedirPosicion();
                      posaf4=Integer.parseInt(posDF);
                      System.out.println("Columna");
                      posDC=PedirPosicion();
                      switch (posDC){
                        case "A":
                              posDC="1";
                              break;
                        case "B":
                              posDC="2";
                              break;
                        case "C":
                              posDC="3";
                              break;
                        case "D":
                              posDC="4";
                              break;
                        case "E":
                              posDC="5";
                              break;
                        case "F":
                              posDC="6";
                              break;
                        case "G":
                              posDC="7";
                              break;
                        case "H":
                              posDC="8";
                              break;
                        case "I":
                              posDC="9";
                              break;
                      }
                      posac4=Integer.parseInt(posDC);
                      break;      
              }
              
              SetRESF1(posaf1);
              SetRESC1(posac1);
              SetRESF2(posaf2);
              SetRESC2(posac2);
              SetRESF3(posaf3);
              SetRESC3(posac3);
              SetRESF4(posaf4);
              SetRESC4(posac4);
              
                Llenar cina = new Llenar();
                Pelicula pel=new Pelicula();
                Sala mos=new Sala();
                System.out.println(" ");
                System.out.println("Distribucion Sala:");
                System.out.println("");
                mos.GenerarMatriz();
                System.out.println(" ");
                System.out.println("Precio entrada");
                System.out.println(mos.GetPRECIO());
                System.out.println(" ");
                System.out.println("Pelicula:");
                pel.peliculas();
                System.out.println("");
                System.out.println("Espectadores en su respectivo puesto:");
                System.out.println(" ");
                cina.Pos();
                System.out.println(" "); 
                
            }
            else{
                System.out.println("No se pueden reservar "+b+" asientos, el sistema se ejecutará normalmente...");
                Llenar cina = new Llenar();
                Pelicula pel=new Pelicula();
                Sala mos=new Sala();
                System.out.println(" ");
                System.out.println("Distribucion Sala:");
                System.out.println("");
                mos.GenerarMatriz();
                System.out.println(" ");
                System.out.println("Precio entrada");
                System.out.println(mos.GetPRECIO());
                System.out.println(" ");
                System.out.println("Pelicula:");
                pel.peliculas();
                System.out.println("");
                System.out.println("Espectadores en su respectivo puesto:");
                System.out.println(" ");
                cina.Pos();
                System.out.println(" ");  
            }

            
        }
        else{
        Llenar cina = new Llenar();
        Pelicula pel=new Pelicula();
        Sala mos=new Sala();
        System.out.println(" ");
        System.out.println("Distribucion Sala:");
        System.out.println("");
        mos.GenerarMatriz();
        System.out.println(" ");
        System.out.println("Precio entrada");
        System.out.println(mos.GetPRECIO());
        System.out.println(" ");
        System.out.println("Pelicula:");
        pel.peliculas();
        System.out.println("");
        System.out.println("Espectadores en su respectivo puesto:");
        System.out.println(" ");
        cina.Pos();
        System.out.println(" ");  
        }

    }
}
