
package cine;


public class Pelicula {
    private String Titulo;
    private int RestEdad;
    private String Director;
    private int Duracion;
    private int Random;
    //Constructor 
    public Pelicula(){
        //System.out.println("Soy el constructor de pelicula");
        Titulo = "";
        RestEdad = 16; 
        Director = "";
        Duracion = 0;
        Random = (int) (Math.random() * 4) + 1;

    }
    // Sets y Gets de los atributos
    public void SetTITULO(String x){
       Titulo = x;       
    }
    public String GetTITULO(){
       return this.Titulo;
    }
    public void SetRESTEDAD(int x){
        RestEdad = x;     
    }
    public double GetRESTEDAD(){
        return this.RestEdad;        
    }
    public void SetDIRECTOR(String x){
        Director = x;
    }
    public String GetDIRECTOR(){
        return this.Director;
    } 
    public void SetDURACION(int x){
        Duracion = x; 
    }
    public int GetDURACION(){
        return this.Duracion ;
    }
    
        public void  Random(){ 
        switch(Random){
            case '1':
                SetTITULO("Piratas del Caribe");
                SetDURACION(90);
                SetDIRECTOR("David Rocha");
                break;
            case '2':
                SetTITULO("La monja");
                SetDURACION(120);
                SetDIRECTOR("David Camargo");
                break;
            case '3':
                SetTITULO("50 Sombras de Grey");
                SetDURACION(150);
                SetDIRECTOR("David Sandoval");
                break;
            case '4':
                SetTITULO("Dragon Ball Z");
                SetDURACION(100);
                SetDIRECTOR("Santiago Olivera");
                break;
                
                
        }
    }
    
    public void peliculas(){
        int a=12;
        int b=16;

        switch (Random){
            case 1:  
                System.out.println("La pelicula 1 tiene los siguientes atributos:");
                System.out.println("Tiulo : Que pasó Ayer \nDuración: 90 min \nDirector : David Rocha \nEdad minima: 16 años");
                System.out.println(""); 
                break;
            case 2:
                System.out.println("La pelicula 2 tiene los siguientes atributos");
                System.out.println("Titulo : La monja \nDuracion: 120 min \nDirector: David Camargo \nEdad mínima: 16 años");
                System.out.println("");
                break;
            case 3:
                System.out.println("La pelicula 3 tiene los siguientes atributos");
                System.out.println("Titulo :50 Sombras de Grey \nDuracion: 150 min \nDirector: David Sandoval \nEdad minima: 16 años");
                System.out.println("");
                break;
            case 4:
                System.out.println("La pelicula 4 tiene los siguientes atributos");
                System.out.println("Titulo: Dragon Ball Z \nDuracion: 100 min \nDirector: Santiago Olivera \nEdad minima: 16 años");
                System.out.println(""); 
                break;   
        }

    }

            
    
}

