package cine;
public class Llenar extends Personas{
    private String [][] Salall =  new String [8][9]; 
    
    public Llenar(){
        for(int i = 0;i<8; i++){
            for(int j = 0; j<9; j++){
                this.Salall[i][j] = "A";
            }
        }
    }
    public String[][]  GetSALALL(){
        return this.Salall;
    }
    public void SetSALALL(String sal[][]){
        this.Salall = sal;
    } 
    
    public Boolean ValidacionEntrada(double Dinero, double Edad, double RestEdad){
         Sala sal = new Sala();
         Pelicula r=new Pelicula();

         if (Edad>=RestEdad){
            if(sal.GetPRECIO()<=Dinero){
                return true;
                }
         }else{
            return false;
         }
         return false;
    }
    
    public void Pos() throws InterruptedException{
        Personas per = new Personas();
        per.Random();
        Pelicula pel = new Pelicula();
        pel.Random();
        boolean segundo=false;
        int cont=0;
        for(int i = 0; i<8;i++){
            for (int j = 0;j<9;j++){
               Sala k=new Sala();
               double f=per.RandomDinero();
               int a=per.GetEDAD();
               double q=pel.GetRESTEDAD();
               per.Random();
                   int x= (int) (Math.random()*8);
                   int y= (int) (Math.random()*9);
               if (ValidacionEntrada(f,a,q)){
                   boolean verf=false;
                if (Salall[x][y]=="A"){
                    Salall[x][y]=per.GetNOMBRE()+" "+per.GetEDAD()+" "+per.GetDINERO();
                    System.out.print("|"+"O"+"|");
                    verf=true;
                    cont++;
                }
                else{
                   verf=false;  
                   while (verf==false){
                   x= (int) (Math.random()*8);
                   y= (int) (Math.random()*9);
                   if (Salall[x][y]=="A"){
                       Salall[x][y]=per.GetNOMBRE()+" "+per.GetEDAD()+" "+per.GetDINERO();
                       System.out.print("|"+"O"+"|");
                       verf=true;
                       cont++;
                  }
                 } 
                }

            }
               else{
               per.Random();
               Salall[x][y]=" ";
                   System.out.print("|"+Salall[x][y]+"|");
               }
               
                 Thread.sleep (30);
            }
            System.out.println(" ");                    
        }
        System.out.println(cont);
        
        while(segundo==false){
            if (cont!=72){
            for(int i = 0; i<8;i++){
            for (int j = 0;j<9;j++){
                if (Salall[i][j]!="A"){
                    System.out.print("|"+"O"+"|");
                }
                else{
                    per.Random();
               double f=per.RandomDinero();
               int a=per.GetEDAD();
               double q=pel.GetRESTEDAD();
                    if (ValidacionEntrada(f,a,q)){
                        
                    }
                }

            }
              System.out.println(" ");   

            }

       System.out.println(cont);  
        if (cont==72){
            segundo=true;
        }
        else{
            segundo=false;
        }
            }
            else{
                segundo=true;
            }    
                    
        }
        
    }
}

 

