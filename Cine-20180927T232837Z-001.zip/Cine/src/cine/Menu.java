package cine;

public class Menu {
    public void menu(){ 
        Llenar cina = new Llenar();
        Pelicula pel=new Pelicula();
        Sala mos=new Sala();
        System.out.println(" ");
        System.out.println("Distribucion Sala:");
        mos.GenerarMatriz();
        System.out.println(" ");
        System.out.println("Precio entrada");
        System.out.println(mos.GetPRECIO());
        System.out.println(" ");
        System.out.println("Pelicula:");
        pel.peliculas();
        System.out.println("Espectadores en su respectivo puesto:");
        System.out.println(" ");
        cina.Pos();     
        System.out.println(" ");
    }
}
