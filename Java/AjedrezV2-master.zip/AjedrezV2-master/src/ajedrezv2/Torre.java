package ajedrezv2;
import ajedrezv2.Ficha;
import java.util.*;

/**
 * 
 */
public class Torre extends Ficha {

    /**
     * Default constructor
     */
    public Torre() {
    }

}