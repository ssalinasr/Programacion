package ajedrezv2;
import java.util.*;

/**
 * 
 */
public class VentanaPartida {

    /**
     * Default constructor
     */
    public VentanaPartida() {
    }

    /**
     * 
     */
    private Partida partidaActual;


    /**
     * @return
     */
    public void crearVentana() {
        // TODO implement here
    }

}