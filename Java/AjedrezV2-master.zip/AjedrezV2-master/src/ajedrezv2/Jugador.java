package ajedrezv2;
import java.util.*;

/**
 * 
 */
public class Jugador {

    /**
     * Default constructor
     */
    public Jugador() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private String equipo;

    /**
     * 
     */
    private boolean estado;


    /**
     * @return
     */
    public void crearJugador() {
        // TODO implement here
    }

}