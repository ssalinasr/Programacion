package ajedrezv2;
import ajedrezv2.Ficha;
import java.util.*;

/**
 * 
 */
public class Peon extends Ficha {

    /**
     * Default constructor
     */
    public Peon() {
    }

}