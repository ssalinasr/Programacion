package ajedrezv2;


import java.util.*;

/**
 * 
 */
public class Reina extends Ficha {

    /**
     * Default constructor
     */
    public Reina() {
    }

}