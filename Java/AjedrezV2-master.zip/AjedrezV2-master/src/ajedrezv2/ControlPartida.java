package ajedrezv2;


import java.util.*;

/**
 * 
 */
public class ControlPartida {

    /**
     * Default constructor
     */
    public ControlPartida() {
    }

    /**
     * 
     */
    private boolean hayGanador;


    /**
     * @return
     */
    public void actual() {
        // TODO implement here
    }

    /**
     * @return
     */
    public void verificarJugada() {
        // TODO implement here
    }

}