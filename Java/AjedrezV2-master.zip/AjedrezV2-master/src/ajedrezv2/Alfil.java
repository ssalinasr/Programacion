package ajedrezv2;


import java.util.*;

/**
 * 
 */
public class Alfil extends Ficha {

    /**
     * Default constructor
     */
    public Alfil() {
    }

}