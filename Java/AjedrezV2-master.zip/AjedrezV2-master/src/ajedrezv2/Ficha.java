package ajedrezv2;


import java.util.*;

/**
 * 
 */
public class Ficha {

    /**
     * Default constructor
     */
    public Ficha() {
    }

    /**
     * 
     */
    private String color;

    /**
     * 
     */
    private int ubicación[][];

    /**
     * 
     */
    private boolean estado;

    /**
     * @param int 
     * @return
     */
    public void mover(int f, int c) {
        // TODO implement here
    }

    /**
     * @return
     */
    public void eliminar() {
        // TODO implement here
    }

    /**
     * @return
     */
    public void realizarAnimacion() {
        // TODO implement here
    }

}