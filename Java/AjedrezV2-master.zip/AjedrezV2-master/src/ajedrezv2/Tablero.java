package ajedrezv2;
import ajedrezv2.Ficha;
import java.util.*;

/**
 * 
 */
public class Tablero {

    /**
     * Default constructor
     */
    public Tablero() {
    }

    /**
     * 
     */
    private Ficha equipoBlanco[][];

    /**
     * 
     */
    private Ficha equipoNegro[][];


    /**
     * @return
     */
    public void crearTablero() {
        // TODO implement here
    }

}