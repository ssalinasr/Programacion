package ajedrezv2;


import java.util.*;

/**
 * 
 */
public class Caballo extends Ficha {

    /**
     * Default constructor
     */
    public Caballo() {
    }

}