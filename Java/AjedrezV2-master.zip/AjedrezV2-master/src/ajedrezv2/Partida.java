package ajedrezv2;
import ajedrezv2.ControlPartida;
import java.util.*;

/**
 * 
 */
public class Partida {

    /**
     * Default constructor
     */
    public Partida() {
    }

    /**
     * 
     */
    private Tablero tableroActual;

    /**
     * 
     */
    private Jugador jugadorA;

    /**
     * 
     */
    private Jugador jugadorB;

    /**
     * 
     */
    private ControlPartida controlador;





    /**
     * @return
     */
    public void crearPartida() {
        // TODO implement here
    }

}