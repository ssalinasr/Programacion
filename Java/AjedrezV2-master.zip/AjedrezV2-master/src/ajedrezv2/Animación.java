package ajedrezv2;
import java.util.*;

/**
 * 
 */
public interface Animación {

    /**
     * @return
     */
    public void realizarAnimacion();

}