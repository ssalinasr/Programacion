
package electrodomesticos;

public class Test {
    
    public static void main(String[] args) {
        Menu a=new Menu();
        a.AsignarValores();
    }
}
